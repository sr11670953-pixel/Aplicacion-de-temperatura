// --- RELOJ EN TIEMPO REAL ---
function actualizarHora() {
  const now = new Date();
  const hora = now.toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" });
  document.getElementById("time").textContent = hora;
}
setInterval(actualizarHora, 1000);
actualizarHora();

// --- CLIMA EN TIEMPO REAL (OpenWeather API) ---
const apiKey = "68fa1a5412583592950683bf18f8053c"; //api key
const ciudad = "Cali"; 

async function obtenerClima() {
  try {
    const respuesta = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${ciudad}&appid=${apiKey}&units=metric&lang=es`
    );
    const datos = await respuesta.json();

    if (respuesta.ok) {
      const temp = Math.round(datos.main.temp);
      const humedad = datos.main.humidity;
      const viento = Math.round(datos.wind.speed);
      const descripcion = datos.weather[0].description;
      const icono = datos.weather[0].icon;

      
      document.getElementById("weather-city").textContent = ciudad;
      document.getElementById("weather-temp").textContent = `${temp}°C`;
      notificarCambioClima(temp);
      document.getElementById("weather-desc").textContent =
        descripcion.charAt(0).toUpperCase() + descripcion.slice(1);
      document.getElementById("weather-humidity").textContent = `${humedad}%`;
      document.getElementById("weather-wind").textContent = `${viento} km/h`;
      document.getElementById("weather-icon").src = `https://openweathermap.org/img/wn/${icono}@2x.png`;
    } else {
      document.getElementById("weather-temp").textContent = "Error";
    }
  } catch (error) {
    console.error("Error al obtener el clima:", error);
  }
}




obtenerClima();
setInterval(obtenerClima, 600000);


// --- GRAFICA DE TEMPERATURAS 
const ctx = document.getElementById("tempChart");
const labels = ["6", "9", "12", "15", "18", "21"];
let tempData = [18, 21, 25, 28, 24, 20]; 


const API_KEY = "68fa1a5412583592950683bf18f8053c"; 
const ciudadAPI = "Cali";

async function obtenerTemperaturasCali() {
  try {
    const url = `https://api.openweathermap.org/data/2.5/forecast?q=${ciudadAPI}&appid=68fa1a5412583592950683bf18f8053c&units=metric&lang=es`;
    const respuesta = await fetch(url);
    const datos = await respuesta.json();

    // Extraer temperaturas aproximadas a las horas deseadas
    const horasDeseadas = [6, 9, 12, 15, 18, 21];
    tempData = horasDeseadas.map(hora => {
      const prediccion = datos.list.find(item => {
        const horaPrediccion = new Date(item.dt_txt).getHours();
        return horaPrediccion === hora;
      });
      return prediccion ? Math.round(prediccion.main.temp) : null;
    });

    // Actualizar gráfico con datos reales
    tempChart.data.datasets[0].data = tempData;
    tempChart.update();
  } catch (error) {
    console.error("Error obteniendo datos del clima:", error);
  }
}

const tempChart = new Chart(ctx, {
  type: "line",
  data: {
    labels: labels,
    datasets: [{
      label: "Temperatura (°C)",
      data: tempData,
      borderColor: "#42a5f5",
      backgroundColor: "rgba(66,165,245,0.2)",
      borderWidth: 2,
      tension: 0.4,
      pointRadius: 4,
      pointHoverRadius: 6
    }]
  },
  options: {
    responsive: true,
    interaction: {
      mode: "nearest",
      intersect: false
    },
    plugins: {
      legend: { labels: { color: "#b3e5fc" } },
      tooltip: {
        enabled: true,
        callbacks: {
          title: function (tooltipItems) {
            const item = tooltipItems[0];
            const index = item.dataIndex;
            const baseHour = parseInt(labels[index]);
            const nextHour = labels[index + 1] ? parseInt(labels[index + 1]) : baseHour + 3;
            const progress = item.parsed.x - index;
            const estimatedHour = baseHour + progress * (nextHour - baseHour);
            const hour = Math.floor(estimatedHour);
            const minutes = Math.round((estimatedHour - hour) * 60);
            const timeStr = new Date(0, 0, 0, hour, minutes).toLocaleTimeString("es-CO", {
              hour: "2-digit",
              minute: "2-digit",
              hour12: true
            });
            return `Hora estimada: ${timeStr}`;
          },
          label: function (context) {
            return `Temperatura: ${context.parsed.y}°C`;
          }
        }
      }
    },
    scales: {
      y: { beginAtZero: true, ticks: { color: "#e3f2fd" } },
      x: { ticks: { color: "#e3f2fd" } }
    }
  }
});

// Llamar la API al cargar la página
obtenerTemperaturasCali();


// --- CALENDARIO DE TEMPERATURAS  ---
const monthYear = document.getElementById("monthYear");
const calendar = document.getElementById("calendar");
const prevMonthBtn = document.getElementById("prevMonth");
const nextMonthBtn = document.getElementById("nextMonth");

let currentDate = new Date();
let temperaturaActual = null; 


async function obtenerClimaConCalendario() {
  try {
    const respuesta = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${ciudad}&appid=${apiKey}&units=metric&lang=es`
    );
    const datos = await respuesta.json();

    if (respuesta.ok) {
      temperaturaActual = Math.round(datos.main.temp);
      generarCalendario(currentDate);
    }
  } catch (error) {
    console.error("Error al obtener el clima para el calendario:", error);
  }
}

function generarTemperaturasSimuladas(año, mes) {
  const diasMes = new Date(año, mes + 1, 0).getDate();
  const temps = {};
  const base = temperaturaActual !== null ? temperaturaActual : 25;

  for (let d = 1; d <= diasMes; d++) {

    const variacion = (Math.sin(d / 2) * 3 + Math.random() * 2 - 1).toFixed(1);
    temps[d] = Math.round(base + parseFloat(variacion));
  }
  return temps;
}

function generarCalendario(fecha) {
  calendar.innerHTML = "";

  const year = fecha.getFullYear();
  const month = fecha.getMonth();
  const temps = generarTemperaturasSimuladas(year, month);

  const primerDia = new Date(year, month, 1);
  const ultimoDia = new Date(year, month + 1, 0);

  const diasSemana = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
  diasSemana.forEach(d => {
    const header = document.createElement("div");
    header.textContent = d;
    header.classList.add("day", "header");
    calendar.appendChild(header);
  });

  
  for (let i = 0; i < primerDia.getDay(); i++) {
    const empty = document.createElement("div");
    calendar.appendChild(empty);
  }

  // Días del mes
  const hoy = new Date();
  for (let i = 1; i <= ultimoDia.getDate(); i++) {
    const day = document.createElement("div");
    day.classList.add("day");

    const tempSpan = document.createElement("div");
    tempSpan.classList.add("temp");

    // Día actual con temperatura real
    if (
      i === hoy.getDate() &&
      month === hoy.getMonth() &&
      year === hoy.getFullYear()
    ) {
      day.classList.add("today");
      tempSpan.textContent =
        temperaturaActual !== null ? `${temperaturaActual}°C` : "Cargando...";
    } else {
      tempSpan.textContent = `${temps[i]}°C`;
    }

    day.textContent = i;
    day.appendChild(tempSpan);
    calendar.appendChild(day);
  }

  const nombreMes = fecha.toLocaleString("es-ES", { month: "long" });
  monthYear.textContent = `${nombreMes.charAt(0).toUpperCase() + nombreMes.slice(1)} ${year}`;
}

prevMonthBtn.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  generarCalendario(currentDate);
});

nextMonthBtn.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  generarCalendario(currentDate);
});

// Espera al clima y luego genera el calendario
obtenerClimaConCalendario();


// --- CONVERSOR ---
function convertir() {
  const tipo = document.getElementById("tipo").value;
  const valor = parseFloat(document.getElementById("valor").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(valor)) {
    resultado.textContent = "Por favor ingresa un número válido.";
    return;
  }

  let res;
  switch (tipo) {
    case "CtoF":
      res = (valor * 9) / 5 + 32;
      break;
    case "FtoC":
      res = ((valor - 32) * 5) / 9;
      break;
    case "CtoK":
      res = valor + 273.15;
      break;
    case "KtoC":
      res = valor - 273.15;
      break;
  }

  resultado.textContent = `Resultado: ${res.toFixed(2)}°`;
}
// --- NOTIFICACIONES PUSH DEL CLIMA ---
if ("serviceWorker" in navigator && "PushManager" in window) {
  navigator.serviceWorker.register("sw.js")
    .then(() => {
      console.log("Service Worker registrado correctamente.");

      Notification.requestPermission().then(permission => {
        if (permission === "granted") {
          console.log("Permiso para notificaciones concedido.");
        } else {
          console.log("Permiso para notificaciones denegado.");
        }
      });
    })
    .catch(err => console.error("Error al registrar el Service Worker:", err));
}

let ultimaTemp = null;

function notificarCambioClima(tempActual) {
  if (ultimaTemp !== null && tempActual !== ultimaTemp) {
    navigator.serviceWorker.ready.then(reg => {
      reg.showNotification("Cambio de temperatura detectado", {
        body: `Nueva temperatura: ${tempActual}°C`,
        icon: "https://cdn-icons-png.flaticon.com/512/1684/1684375.png"
      });
    });
  }
  ultimaTemp = tempActual;
}
